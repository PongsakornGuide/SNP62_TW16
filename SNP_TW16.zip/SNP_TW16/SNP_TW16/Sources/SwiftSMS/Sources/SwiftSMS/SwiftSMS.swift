struct SwiftSMS {
    var text = "Hello, World!"
}
