import XCTest

import SwiftSMSTests

var tests = [XCTestCaseEntry]()
tests += SwiftSMSTests.allTests()
XCTMain(tests)
