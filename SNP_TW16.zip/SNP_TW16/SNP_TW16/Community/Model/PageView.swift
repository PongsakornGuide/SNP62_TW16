////
////  PageView.swift
////  SNP_TW16
////
////  Created by Guide on 29/12/2562 BE.
////  Copyright © 2562 guide. All rights reserved.
////
//
//import UIKit
//struct PageView {
//    var title : String?
//    init(title: String?) {
//        self.title = title
//    }
//}
